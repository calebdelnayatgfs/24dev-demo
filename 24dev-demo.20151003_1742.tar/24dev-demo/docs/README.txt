Instructions to install 24dev-demo to an OSGeo system:
* Download the latest version of the 24dev-demo tar file and install on a USB flash drive.  
* Boot your computer with the OSGeo Live DVD.
* Copy the tar file to the OSGeo Desktop
* Open a terminal window on the Desktop and type the following command to extract 
  the contents of the program to the Desktop:
    tar -xf 24dev-demo*.tar 
* Navigate inside the 24dev-demo folder, open a terminal window and run the following command:
    ./apps/install2Osgeo/install2Osgeo.sh
* The above command will create databases, install and test the required programs.
* The program documentation is located online at: TBD 

cat <<-EOF 
Various R scripts to demonstrate batch R sripting techniques.
Usage: ./<scriptName.r>
EOF
echo 

# Display the applicable Release and License Details:
cat ${DOCS}/24dev-demo-ReleaseAndLicense.txt

